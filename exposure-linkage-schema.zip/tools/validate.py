"""Validate metadata YAML/JSON files against exposure_linkage.schema.json.

Usage: python validate.py file1.yaml [file2.yaml ...]
Exit code 1 if any file is invalid (suitable for GitHub Actions).
"""
import json, sys, yaml
from jsonschema import Draft202012Validator

import os
schema = json.load(open(os.path.join(os.path.dirname(__file__), "..", "schema", "exposure_linkage.schema.json")))
v = Draft202012Validator(schema, format_checker=Draft202012Validator.FORMAT_CHECKER)
bad = 0
for f in sys.argv[1:]:
    # YAML parses unquoted dates into date objects; round-trip through JSON as strings
    data = json.loads(json.dumps(yaml.safe_load(open(f)), default=str))
    errs = sorted(v.iter_errors(data), key=lambda e: list(e.absolute_path))
    print(f"{'PASS' if not errs else 'FAIL'}  {f}  ({len(errs)} errors)")
    for e in errs:
        path = "/".join(map(str, e.absolute_path)) or "(root)"
        print(f"   - {path}: {e.message[:120]}")
    bad += bool(errs)
sys.exit(1 if bad else 0)
