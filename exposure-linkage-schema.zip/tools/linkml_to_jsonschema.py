"""Minimal LinkML -> JSON Schema 2020-12 converter for exposure_linkage_schema.yaml.

Stand-in for LinkML's `gen-json-schema` (use that in CI). Covers the subset
this schema uses: attributes, ranges, required, multivalued, patterns,
min/max, enums, custom string types, and simple equals_string -> required rules.
"""
import json, sys, yaml

PRIMS = {"string": {"type": "string"}, "integer": {"type": "integer"},
         "float": {"type": "number"}, "boolean": {"type": "boolean"},
         "date": {"type": "string", "format": "date"},
         "uri": {"type": "string", "format": "uri"},
         "uriorcurie": {"type": "string"}}

def convert(src):
    s = yaml.safe_load(open(src))
    default = s.get("default_range", "string")
    types, enums, classes = s.get("types", {}), s.get("enums", {}), s["classes"]

    def range_schema(r):
        if r in classes:
            return {"$ref": f"#/$defs/{r}"}
        if r in enums:
            return {"$ref": f"#/$defs/{r}"}
        if r in types:
            t = types[r]
            out = dict(range_schema(t["typeof"]))
            if "pattern" in t: out["pattern"] = t["pattern"]
            if "description" in t: out["description"] = t["description"]
            return out
        return dict(PRIMS[r])

    defs = {}
    for name, e in enums.items():
        defs[name] = {"type": "string", "enum": list(e["permissible_values"])}
    for name, c in classes.items():
        props, req = {}, []
        for an, a in (c.get("attributes") or {}).items():
            a = a or {}
            item = range_schema(a.get("range", default))
            for k, jk in (("pattern", "pattern"), ("minimum_value", "minimum"),
                          ("maximum_value", "maximum")):
                if k in a: item[jk] = a[k]
            if a.get("multivalued"):
                p = {"type": "array", "items": item}
                if a.get("required"): p["minItems"] = 1
            else:
                p = item
            if "description" in a: p = {**p, "description": a["description"]}
            props[an] = p
            if a.get("required"): req.append(an)
        d = {"type": "object", "properties": props, "additionalProperties": False}
        if "description" in c: d["description"] = c["description"]
        if req: d["required"] = req
        conds = []
        for rule in c.get("rules", []):
            pre = rule["preconditions"]["slot_conditions"]
            post = rule["postconditions"]["slot_conditions"]
            if_props = {}
            for k, v in pre.items():
                val = v["equals_string"]
                if props[k].get("type") == "boolean":
                    val = val == "true"
                if_props[k] = {"const": val}
            conds.append({"if": {"properties": if_props, "required": list(pre)},
                          "then": {"required": [k for k, v in post.items() if v.get("required")]},
                          "$comment": rule.get("description", "")})
        if conds: d["allOf"] = conds
        if c.get("any_of"):
            d["anyOf"] = [{"required": [k for k, v in alt["slot_conditions"].items() if v.get("required")]}
                          for alt in c["any_of"]]
        defs[name] = d

    root = next(n for n, c in classes.items() if c.get("tree_root"))
    return {"$schema": "https://json-schema.org/draft/2020-12/schema",
            "$id": s["id"], "title": s.get("title", s["name"]),
            "description": s.get("description", ""), "version": s.get("version"),
            "$ref": f"#/$defs/{root}", "$defs": defs}

if __name__ == "__main__":
    json.dump(convert(sys.argv[1]), sys.stdout, indent=2, ensure_ascii=False)
